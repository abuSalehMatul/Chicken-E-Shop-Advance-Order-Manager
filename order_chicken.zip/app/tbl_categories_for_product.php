<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_categories_for_product extends Model
{
    protected $table = 'tbl_categories_for_products';
}
