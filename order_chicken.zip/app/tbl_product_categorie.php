<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_product_categorie extends Model
{
    protected $table=tbl_product_categories;
}
