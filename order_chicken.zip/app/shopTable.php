<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shopTable extends Model
{
    //
}
